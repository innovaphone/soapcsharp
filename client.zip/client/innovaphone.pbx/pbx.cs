using System;
using System.Xml;
using System.Runtime.Remoting.Metadata;

namespace innovaphone
{

    /// <summary>
    /// the class ipbx contains the top-level methods of the innovaphone iPbx API.
    /// </summary>
    public class pbx :  MarshalByRefObject
    {
        /// <summary>
        /// echo
        /// </summary>
        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#Echo", XmlNamespace="http://innovaphone.com/pbx")]
        public void Echo()
        {
        }

        /// <summary>
        /// test
        /// </summary>
        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#Admin", XmlNamespace="http://innovaphone.com/pbx")]
        public void Admin(string xml)
        {
        }
        /// <summary>
        /// Initialize the PBX session
        /// </summary>
        /// <returns>
        /// A handle to the new session
        /// </returns>
        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#Initialize", XmlNamespace="http://innovaphone.com/pbx")]
        public int Initialize(string user)
        {
            Console.WriteLine("Initialize");
            return 1;
        }

        /// <summary>
        /// end the session
        /// </summary>
        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#End", XmlNamespace="http://innovaphone.com/pbx")]
        public void End(int session)
        {
        }

        /// <summary>
        /// GetInfo
        /// </summary>
        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#Poll", XmlNamespace="http://innovaphone.com/pbx")]
        public object[] Poll(int session)
        {
            return null;
        }

        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserInitialize", XmlNamespace="http://innovaphone.com/pbx")]
        public int UserInitialize(int session, string user)
        {
            return 1;
        }

        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserCall", XmlNamespace="http://innovaphone.com/pbx")]
        public int UserCall(int user, string cn, string e164, string h323)
        {
            return 1;
        }

        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserConnect", XmlNamespace="http://innovaphone.com/pbx")]
        public void UserConnect(int call)
        {
        }

        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserTransfer", XmlNamespace="http://innovaphone.com/pbx")]
        public void UserTransfer(int a, int b)
        {
        }
/*

        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserRedirect", XmlNamespace="http://innovaphone.com/pbx")]
        public int UserRedirect(int call, string cn, string e164, string h323)
        {
            return 1;
        }
*/		
		[SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserRedirect", XmlNamespace="http://innovaphone.com/pbx")]
		public void UserRedirect(int call, string cn, string e164, string h323)
		{
		}

        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserPickup", XmlNamespace="http://innovaphone.com/pbx")]
        public void UserPickup(int user, string cn, int call)
        {
        }

        [SoapMethodAttribute(SoapAction="http://innovaphone.com/pbx#UserClear", XmlNamespace="http://innovaphone.com/pbx")]
        public void UserClear(int call, int cause)
        {
        }
    }

    /// <summary>
    /// top level information of a call. Contains only basic information to keep
    /// the volume of data low even for a large number of calls
    /// </summary>
    [Serializable()]
    [SoapTypeAttribute(XmlNamespace="http://innovaphone.com/pbx")]

    public struct UserInfo 
    {
        /// <summary>
        /// endpoint type, e.g. pseudo-user, endpoint, gateway, ....
        /// </summary>
        public string type;

        /// <summary>
        /// indicates that this call was deleted
        /// </summary>
        public bool active;

        /// <summary>
        /// The state of the user
        /// </summary>
        public int state;

        /// <summary>
        /// number of active channels
        /// </summary>
        public int channel;

        /// <summary>
        /// number of alerts pending
        /// </summary>
        public int alert;

        /// <summary>
        /// the common name (LDAP) of the endpoint
        /// </summary>
        public string cn;

        /// <summary>
        /// the remote number
        /// </summary>
        public string e164;

        /// <summary>
        /// the remote H.323 Id
        /// </summary>
        public string h323;

        /// <summary>
        /// the display name
        /// </summary>
        public string dn;
    }

    /// <summary>
    /// top level information of a call. Contains only basic information to keep
    /// the volume of data low even for a large number of calls
    /// </summary>
    [Serializable()]
    [SoapTypeAttribute(XmlNamespace="http://innovaphone.com/pbx")]
    public struct CallInfo 
    {
        /// <summary>
        /// the user this call belongs to
        /// </summary>
        public int user;

        /// <summary>
        /// handle
        /// </summary>
        public int call;

        /// <summary>
        /// indicates that this call was deleted
        /// </summary>
        public bool active;

        /// <summary>
        /// The state of the call
        /// </summary>
        public int state;

        /// <summary>
        /// the common name (LDAP) of the endpoint
        /// </summary>
        public string cn;

        /// <summary>
        /// the remote number
        /// </summary>
        public string e164;

        /// <summary>
        /// the remote H.323 Id
        /// </summary>
        public string h323;

        /// <summary>
        /// the display name
        /// </summary>
        public string dn;
    }
}

