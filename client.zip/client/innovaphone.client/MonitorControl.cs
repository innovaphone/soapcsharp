using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using innovaphone.com.innovaphone.www;

namespace innovaphone
{
	/// <summary>
	/// Summary description for MonitorControl.
	/// </summary>
	public class MonitorControl : System.Windows.Forms.UserControl
	{
        private pbx pbx;
        private int user_handle;

        private System.Windows.Forms.GroupBox monitorBox;
        private System.Windows.Forms.ListView listView_calls;
        private System.Windows.Forms.ColumnHeader calls_Header1;
        private System.Windows.Forms.ColumnHeader calls_Header2;
        private System.Windows.Forms.ColumnHeader calls_Header3;
        private System.Windows.Forms.ColumnHeader calls_Header4;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MonitorControl(pbx pbx, string user, int user_handle)
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

            this.pbx = pbx;
            this.monitorBox.Text = user;
            this.user_handle = user_handle;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.listView_calls = new System.Windows.Forms.ListView();
            this.calls_Header1 = new System.Windows.Forms.ColumnHeader();
            this.calls_Header2 = new System.Windows.Forms.ColumnHeader();
            this.calls_Header3 = new System.Windows.Forms.ColumnHeader();
            this.calls_Header4 = new System.Windows.Forms.ColumnHeader();
            this.monitorBox = new System.Windows.Forms.GroupBox();
            this.monitorBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // listView_calls
            // 
            this.listView_calls.AllowDrop = true;
            this.listView_calls.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                             this.calls_Header1,
                                                                                             this.calls_Header2,
                                                                                             this.calls_Header3,
                                                                                             this.calls_Header4});
            this.listView_calls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_calls.FullRowSelect = true;
            this.listView_calls.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView_calls.Location = new System.Drawing.Point(3, 16);
            this.listView_calls.Name = "listView_calls";
            this.listView_calls.Size = new System.Drawing.Size(290, 65);
            this.listView_calls.TabIndex = 0;
            this.listView_calls.View = System.Windows.Forms.View.Details;
            this.listView_calls.DragDrop += new System.Windows.Forms.DragEventHandler(this.Monitor_DragDrop);
            this.listView_calls.DragEnter += new System.Windows.Forms.DragEventHandler(this.Monitor_DragEnter);
            this.listView_calls.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.Monitor_ItemDrag);
            // 
            // calls_Header1
            // 
            this.calls_Header1.Text = "";
            this.calls_Header1.Width = 15;
            // 
            // calls_Header2
            // 
            this.calls_Header2.Text = "Remote";
            this.calls_Header2.Width = 80;
            // 
            // calls_Header3
            // 
            this.calls_Header3.Text = "State";
            this.calls_Header3.Width = 80;
            // 
            // calls_Header4
            // 
            this.calls_Header4.Text = "";
            this.calls_Header4.Width = 200;
            // 
            // monitorBox
            // 
            this.monitorBox.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                     this.listView_calls});
            this.monitorBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.monitorBox.Name = "monitorBox";
            this.monitorBox.Size = new System.Drawing.Size(296, 84);
            this.monitorBox.TabIndex = 0;
            this.monitorBox.TabStop = false;
            // 
            // MonitorControl
            // 
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.monitorBox});
            this.Name = "MonitorControl";
            this.Size = new System.Drawing.Size(296, 84);
            this.monitorBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

        public int user
        {
            get { return user_handle; } 
        }

        public void update(CallInfo callInfo)
        {
            Call existing = null;
            foreach(Call c in listView_calls.Items) 
            {
                if(c.handle==callInfo.call) 
                {
                    existing = c;
                    break;
                }
            }
            if(existing==null) 
            {
                if(callInfo.active) 
                {
                    listView_calls.Items.Add(new Call(callInfo));
                }
            }
            else
            {
                if(callInfo.active) 
                {
                    existing.Update(callInfo);
                }
                else
                {
                    listView_calls.Items.Remove(existing);
                }
            }
        }

        private void Monitor_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            Console.WriteLine("Monitor_DragEnter");
            e.Effect = System.Windows.Forms.DragDropEffects.Copy;
        }

        private void Monitor_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            Console.WriteLine("Monitor_DragDrop "+sender);

            Call call = (Call)e.Data.GetData(typeof(Call));

            if(call!=null)
            {
                pbx.UserRedirect(call.handle,monitorBox.Text,null,null,(Info[])null);
                Console.WriteLine("UserRedirect");
            }
        }

        private void Monitor_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
        {
            Console.WriteLine("Monitor_ItemDrag");
            this.DoDragDrop(listView_calls.SelectedItems[0],System.Windows.Forms.DragDropEffects.Copy);
            Console.WriteLine("done");
        }
	}
}
