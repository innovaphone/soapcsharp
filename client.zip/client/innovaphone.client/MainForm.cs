using System;
using System.Windows.Forms;
using System.Runtime.Remoting.Messaging;
using Microsoft.Win32;
using innovaphone.com.innovaphone.www;

namespace innovaphone
{
    /// <summary>
    /// Summary description for MainWin.
    /// </summary>
    public class MainForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem menuItem1;

        private pbx pbx;
        private string user;
        private string[] monitor;
        private int session_handle;
        private int user_handle;
        private bool dial_name;
        private AsyncCallback asyncPoll;

        private System.Windows.Forms.ListView listView_users;
        private System.Windows.Forms.ContextMenu contextMenu_calls;
        private System.Windows.Forms.MenuItem callsClear;
        private System.Windows.Forms.MenuItem callsConnect;
        private System.Windows.Forms.MenuItem menuItemExit;
        private System.Windows.Forms.MenuItem menuItemConfig;
        private System.Windows.Forms.MenuItem callsTransfer;
        private System.Windows.Forms.StatusBar statusBar1;
        private System.Windows.Forms.StatusBarPanel statusBarPanel1;
        private System.Windows.Forms.StatusBarPanel statusBarPanel2;
        private System.Windows.Forms.MenuItem menuItemView;
        private System.Windows.Forms.MenuItem menuItemViewGroup;
        private System.Windows.Forms.MenuItem menuItemViewGroupDetails;
        private System.Windows.Forms.MenuItem menuItemViewGroupSmallIcons;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.GroupBox groupBox_calls1;
        private System.Windows.Forms.ListView listView_calls1;
        private System.Windows.Forms.ColumnHeader calls1_Header1;
        private System.Windows.Forms.ColumnHeader calls1_Header2;
        private System.Windows.Forms.ColumnHeader calls1_Header3;
        private System.Windows.Forms.ColumnHeader calls1_Header4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox calls1_comboBox;
        private System.Windows.Forms.Button button_call;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_Name_Number;
        private System.Windows.Forms.MenuItem callsCtComplete;
        private System.Windows.Forms.MenuItem callsFastClear;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.MenuItem callsSearch;
        private System.Windows.Forms.ColumnHeader header_no;
        private System.Windows.Forms.ColumnHeader header_loc;
        private System.Windows.Forms.ColumnHeader header_h323;
        private System.Windows.Forms.ColumnHeader header_cn;
        private System.Windows.Forms.MenuItem menuItem_calls_clear;
        private System.Windows.Forms.MenuItem menuItem_calls_fastclear;
        private System.Windows.Forms.MenuItem menuItem_calls_hold;
        private System.Windows.Forms.MenuItem menuItem_calls_retrieve;
        private System.Windows.Forms.MenuItem menuItem_calls_connect;
        private System.Windows.Forms.MenuItem menuItem_call_transfer;
        private System.Windows.Forms.MenuItem menuItem2;
        private System.Windows.Forms.MenuItem menuItem_Search;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;

        internal MainForm(pbx pbx, string user, string[] monitor)
        {
            //
            // Required for Windows Form Designer support
            //
            Console.WriteLine("main");
            InitializeComponent();

            this.pbx = pbx;
            this.user = user;
            this.monitor = monitor;
            this.asyncPoll = new AsyncCallback(this.PollCallback);

            groupBox_calls1.Text = user;

            if(SetupSession())
            {
                pbx.BeginPoll(session_handle,asyncPoll,null);
            }
            else
            {
                RegistryKey regKey = Registry.CurrentUser;
                RegistryKey clientKey = regKey.CreateSubKey("Software\\innovaphone\\client");

                ConfigForm config = new ConfigForm(clientKey);
                config.ShowDialog();
            }
            Application.ApplicationExit += new EventHandler(Form_onExit);

            listView_calls1.ContextMenu = contextMenu_calls;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if(components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.callsClear = new System.Windows.Forms.MenuItem();
            this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
            this.menuItemViewGroupDetails = new System.Windows.Forms.MenuItem();
            this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItemConfig = new System.Windows.Forms.MenuItem();
            this.menuItemExit = new System.Windows.Forms.MenuItem();
            this.calls1_Header2 = new System.Windows.Forms.ColumnHeader();
            this.calls1_Header3 = new System.Windows.Forms.ColumnHeader();
            this.calls1_Header1 = new System.Windows.Forms.ColumnHeader();
            this.calls1_comboBox = new System.Windows.Forms.ComboBox();
            this.menuItemView = new System.Windows.Forms.MenuItem();
            this.menuItemViewGroup = new System.Windows.Forms.MenuItem();
            this.menuItemViewGroupSmallIcons = new System.Windows.Forms.MenuItem();
            this.button_Name_Number = new System.Windows.Forms.Button();
            this.calls1_Header4 = new System.Windows.Forms.ColumnHeader();
            this.groupBox_calls1 = new System.Windows.Forms.GroupBox();
            this.listView_calls1 = new System.Windows.Forms.ListView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_call = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.listView_users = new System.Windows.Forms.ListView();
            this.header_no = new System.Windows.Forms.ColumnHeader();
            this.header_h323 = new System.Windows.Forms.ColumnHeader();
            this.header_cn = new System.Windows.Forms.ColumnHeader();
            this.header_loc = new System.Windows.Forms.ColumnHeader();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.callsTransfer = new System.Windows.Forms.MenuItem();
            this.contextMenu_calls = new System.Windows.Forms.ContextMenu();
            this.menuItem_calls_clear = new System.Windows.Forms.MenuItem();
            this.menuItem_calls_fastclear = new System.Windows.Forms.MenuItem();
            this.menuItem_calls_hold = new System.Windows.Forms.MenuItem();
            this.menuItem_calls_retrieve = new System.Windows.Forms.MenuItem();
            this.menuItem_calls_connect = new System.Windows.Forms.MenuItem();
            this.menuItem_call_transfer = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem_Search = new System.Windows.Forms.MenuItem();
            this.callsFastClear = new System.Windows.Forms.MenuItem();
            this.callsConnect = new System.Windows.Forms.MenuItem();
            this.callsCtComplete = new System.Windows.Forms.MenuItem();
            this.callsSearch = new System.Windows.Forms.MenuItem();
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.splitter3 = new System.Windows.Forms.Splitter();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
            this.groupBox_calls1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // callsClear
            // 
            this.callsClear.Index = -1;
            this.callsClear.Text = "Clear";
            this.callsClear.Click += new System.EventHandler(this.callsClear_event);
            // 
            // statusBarPanel1
            // 
            this.statusBarPanel1.Text = "Ready";
            // 
            // menuItemViewGroupDetails
            // 
            this.menuItemViewGroupDetails.Index = 1;
            this.menuItemViewGroupDetails.Text = "Details";
            this.menuItemViewGroupDetails.Click += new System.EventHandler(this.ViewGroupDetails);
            // 
            // statusBarPanel2
            // 
            this.statusBarPanel2.Alignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.statusBarPanel2.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
            this.statusBarPanel2.Width = 648;
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                      this.menuItemConfig,
                                                                                      this.menuItemExit});
            this.menuItem1.ShowShortcut = false;
            this.menuItem1.Text = "&File";
            // 
            // menuItemConfig
            // 
            this.menuItemConfig.Index = 0;
            this.menuItemConfig.Text = "Config";
            this.menuItemConfig.Click += new System.EventHandler(this.Config_clicked);
            // 
            // menuItemExit
            // 
            this.menuItemExit.Index = 1;
            this.menuItemExit.Text = "Exit";
            this.menuItemExit.Click += new System.EventHandler(this.FileExit_Clicked);
            // 
            // calls1_Header2
            // 
            this.calls1_Header2.Text = "Remote";
            this.calls1_Header2.Width = 80;
            // 
            // calls1_Header3
            // 
            this.calls1_Header3.Text = "State";
            this.calls1_Header3.Width = 80;
            // 
            // calls1_Header1
            // 
            this.calls1_Header1.Text = "";
            this.calls1_Header1.Width = 15;
            // 
            // calls1_comboBox
            // 
            this.calls1_comboBox.DropDownWidth = 160;
            this.calls1_comboBox.Location = new System.Drawing.Point(64, 4);
            this.calls1_comboBox.Name = "calls1_comboBox";
            this.calls1_comboBox.Size = new System.Drawing.Size(132, 21);
            this.calls1_comboBox.TabIndex = 1;
            this.calls1_comboBox.SelectionChangeCommitted += new System.EventHandler(this.dialed_selected);
            // 
            // menuItemView
            // 
            this.menuItemView.Index = 1;
            this.menuItemView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                         this.menuItemViewGroup});
            this.menuItemView.ShowShortcut = false;
            this.menuItemView.Text = "&View";
            // 
            // menuItemViewGroup
            // 
            this.menuItemViewGroup.Index = 0;
            this.menuItemViewGroup.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                              this.menuItemViewGroupSmallIcons,
                                                                                              this.menuItemViewGroupDetails});
            this.menuItemViewGroup.Text = "Group";
            // 
            // menuItemViewGroupSmallIcons
            // 
            this.menuItemViewGroupSmallIcons.Index = 0;
            this.menuItemViewGroupSmallIcons.Text = "SmallIcons";
            this.menuItemViewGroupSmallIcons.Click += new System.EventHandler(this.ViewGroupSmallIcons_event);
            // 
            // button_Name_Number
            // 
            this.button_Name_Number.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_Name_Number.Location = new System.Drawing.Point(4, 4);
            this.button_Name_Number.Name = "button_Name_Number";
            this.button_Name_Number.Size = new System.Drawing.Size(60, 20);
            this.button_Name_Number.TabIndex = 0;
            this.button_Name_Number.Text = "Number";
            this.button_Name_Number.Click += new System.EventHandler(this.Name_Number_Click);
            // 
            // calls1_Header4
            // 
            this.calls1_Header4.Text = "";
            this.calls1_Header4.Width = 200;
            // 
            // groupBox_calls1
            // 
            this.groupBox_calls1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                          this.listView_calls1,
                                                                                          this.panel2});
            this.groupBox_calls1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_calls1.Name = "groupBox_calls1";
            this.groupBox_calls1.Size = new System.Drawing.Size(396, 116);
            this.groupBox_calls1.TabIndex = 10;
            this.groupBox_calls1.TabStop = false;
            // 
            // listView_calls1
            // 
            this.listView_calls1.AllowDrop = true;
            this.listView_calls1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                              this.calls1_Header1,
                                                                                              this.calls1_Header2,
                                                                                              this.calls1_Header3,
                                                                                              this.calls1_Header4});
            this.listView_calls1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_calls1.FullRowSelect = true;
            this.listView_calls1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView_calls1.Location = new System.Drawing.Point(3, 48);
            this.listView_calls1.Name = "listView_calls1";
            this.listView_calls1.Size = new System.Drawing.Size(390, 65);
            this.listView_calls1.TabIndex = 5;
            this.listView_calls1.View = System.Windows.Forms.View.Details;
            this.listView_calls1.DragDrop += new System.Windows.Forms.DragEventHandler(this.calls1_DragDrop);
            this.listView_calls1.DragEnter += new System.Windows.Forms.DragEventHandler(this.calls1_DragEnter);
            this.listView_calls1.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.calls1_ItemDrag);
            // 
            // panel2
            // 
            this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                 this.button_Name_Number,
                                                                                 this.button_clear,
                                                                                 this.button_call,
                                                                                 this.calls1_comboBox});
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(390, 32);
            this.panel2.TabIndex = 7;
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(260, 4);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(40, 20);
            this.button_clear.TabIndex = 3;
            this.button_clear.Text = "Clear";
            this.button_clear.Click += new System.EventHandler(this.callsClear_event);
            // 
            // button_call
            // 
            this.button_call.Location = new System.Drawing.Point(212, 4);
            this.button_call.Name = "button_call";
            this.button_call.Size = new System.Drawing.Size(40, 20);
            this.button_call.TabIndex = 2;
            this.button_call.Text = "Call";
            this.button_call.Click += new System.EventHandler(this.button_call_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                 this.splitter1,
                                                                                 this.groupBox_calls1});
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(396, 277);
            this.panel1.TabIndex = 11;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter1.Location = new System.Drawing.Point(0, 116);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(396, 4);
            this.splitter1.TabIndex = 9;
            this.splitter1.TabStop = false;
            // 
            // listView_users
            // 
            this.listView_users.Alignment = System.Windows.Forms.ListViewAlignment.SnapToGrid;
            this.listView_users.AllowDrop = true;
            this.listView_users.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                             this.header_no,
                                                                                             this.header_h323,
                                                                                             this.header_cn,
                                                                                             this.header_loc});
            this.listView_users.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView_users.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.listView_users.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView_users.Location = new System.Drawing.Point(399, 0);
            this.listView_users.Name = "listView_users";
            this.listView_users.Size = new System.Drawing.Size(297, 277);
            this.listView_users.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listView_users.TabIndex = 4;
            this.listView_users.View = System.Windows.Forms.View.Details;
            this.listView_users.Click += new System.EventHandler(this.listView_users_Click);
            this.listView_users.DoubleClick += new System.EventHandler(this.listView_users_DoubleClick);
            this.listView_users.DragOver += new System.Windows.Forms.DragEventHandler(this.users_DragOver);
            this.listView_users.DragDrop += new System.Windows.Forms.DragEventHandler(this.users_DragDrop);
            this.listView_users.DragEnter += new System.Windows.Forms.DragEventHandler(this.users_DragEnter);
            this.listView_users.SelectedIndexChanged += new System.EventHandler(this.listView_users_SelectedIndexChanged);
            // 
            // header_no
            // 
            this.header_no.Text = "no";
            this.header_no.Width = 40;
            // 
            // header_h323
            // 
            this.header_h323.Text = "h323";
            this.header_h323.Width = 40;
            // 
            // header_cn
            // 
            this.header_cn.Text = "cn";
            this.header_cn.Width = 120;
            // 
            // header_loc
            // 
            this.header_loc.Text = "loc";
            // 
            // splitter2
            // 
            this.splitter2.Location = new System.Drawing.Point(396, 0);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(3, 277);
            this.splitter2.TabIndex = 12;
            this.splitter2.TabStop = false;
            // 
            // callsTransfer
            // 
            this.callsTransfer.Index = -1;
            this.callsTransfer.Text = "Tranfer";
            this.callsTransfer.Click += new System.EventHandler(this.callsTransfer_event);
            // 
            // contextMenu_calls
            // 
            this.contextMenu_calls.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                              this.menuItem_calls_clear,
                                                                                              this.menuItem_calls_fastclear,
                                                                                              this.menuItem_calls_hold,
                                                                                              this.menuItem_calls_retrieve,
                                                                                              this.menuItem_calls_connect,
                                                                                              this.menuItem_call_transfer,
                                                                                              this.menuItem2,
                                                                                              this.menuItem_Search});
            // 
            // menuItem_calls_clear
            // 
            this.menuItem_calls_clear.Index = 0;
            this.menuItem_calls_clear.Text = "Clear";
            this.menuItem_calls_clear.Click += new System.EventHandler(this.callsClear_event);
            // 
            // menuItem_calls_fastclear
            // 
            this.menuItem_calls_fastclear.Index = 1;
            this.menuItem_calls_fastclear.Text = "Fast Clear";
            this.menuItem_calls_fastclear.Click += new System.EventHandler(this.callFastClear_event);
            // 
            // menuItem_calls_hold
            // 
            this.menuItem_calls_hold.Index = 2;
            this.menuItem_calls_hold.Text = "Hold";
            this.menuItem_calls_hold.Click += new System.EventHandler(this.CallsHold_event);
            // 
            // menuItem_calls_retrieve
            // 
            this.menuItem_calls_retrieve.Index = 3;
            this.menuItem_calls_retrieve.Text = "Retrieve";
            this.menuItem_calls_retrieve.Click += new System.EventHandler(this.CallsRetrieve_event);
            // 
            // menuItem_calls_connect
            // 
            this.menuItem_calls_connect.Index = 4;
            this.menuItem_calls_connect.Text = "Connect";
            // 
            // menuItem_call_transfer
            // 
            this.menuItem_call_transfer.Index = 5;
            this.menuItem_call_transfer.Text = "Transfer";
            this.menuItem_call_transfer.Click += new System.EventHandler(this.callsTransfer_event);
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 6;
            this.menuItem2.Text = "CtComplete";
            this.menuItem2.Click += new System.EventHandler(this.callsCtComplete_event);
            // 
            // menuItem_Search
            // 
            this.menuItem_Search.Index = 7;
            this.menuItem_Search.Text = "Search";
            this.menuItem_Search.Click += new System.EventHandler(this.callsSearch_Click);
            // 
            // callsFastClear
            // 
            this.callsFastClear.Index = -1;
            this.callsFastClear.Text = "Fast Clear";
            this.callsFastClear.Click += new System.EventHandler(this.callFastClear_event);
            // 
            // callsConnect
            // 
            this.callsConnect.Index = -1;
            this.callsConnect.Text = "Connect";
            this.callsConnect.Click += new System.EventHandler(this.callsConnect_event);
            // 
            // callsCtComplete
            // 
            this.callsCtComplete.Index = -1;
            this.callsCtComplete.Text = "CtComplete";
            this.callsCtComplete.Click += new System.EventHandler(this.callsCtComplete_event);
            // 
            // callsSearch
            // 
            this.callsSearch.Index = -1;
            this.callsSearch.Text = "Search";
            this.callsSearch.Click += new System.EventHandler(this.callsSearch_Click);
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                      this.menuItem1,
                                                                                      this.menuItemView});
            // 
            // statusBar1
            // 
            this.statusBar1.Location = new System.Drawing.Point(0, 277);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                                                                                          this.statusBarPanel1,
                                                                                          this.statusBarPanel2});
            this.statusBar1.ShowPanels = true;
            this.statusBar1.Size = new System.Drawing.Size(764, 20);
            this.statusBar1.TabIndex = 10;
            // 
            // splitter3
            // 
            this.splitter3.Location = new System.Drawing.Point(696, 0);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(3, 277);
            this.splitter3.TabIndex = 13;
            this.splitter3.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(764, 297);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.splitter3,
                                                                          this.listView_users,
                                                                          this.splitter2,
                                                                          this.panel1,
                                                                          this.statusBar1});
            this.Menu = this.mainMenu1;
            this.Name = "MainForm";
            this.Text = "innovaphone client";
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
            this.groupBox_calls1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        internal bool SetupSession()
        {
            try 
            {
                if(session_handle==0)
                {
                    int key;
                    session_handle = pbx.Initialize(user,"Client 1.0",true,true,out key);
                    string license = pbx.License(session_handle,"innovaphone=1,101");
                    Console.WriteLine("License "+license);
					if( 0 == session_handle )
					{
						MessageBox.Show("Can't get Session Handle");
						return( false );
					}
                    Console.WriteLine("Initialize ok, session=" + session_handle);
                }

                if(user_handle==0) 
                {
                    user_handle = pbx.UserInitialize(session_handle,user,true);
					if( 0 == user_handle )
					{
						MessageBox.Show("Can't get User Handle");
						return( false );
					}
					Console.WriteLine("UserInitialize ok");
                }
                foreach(string monitor_user in monitor)
                {
                    int monitor_handle = pbx.UserInitialize(session_handle,monitor_user,false);
                    Console.WriteLine("Monitor "+monitor_handle);
                    if(monitor_handle!=0)
                    {
                        MonitorControl m = new MonitorControl(pbx,monitor_user,monitor_handle);
                        m.Dock = System.Windows.Forms.DockStyle.Top;
                        panel1.Controls.Add(m);
                        panel1.Controls.SetChildIndex(m,0);
                
                        Splitter s = new Splitter();
                        s.Dock = System.Windows.Forms.DockStyle.Top;
                        panel1.Controls.Add(s);
                        panel1.Controls.SetChildIndex(s,0);
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public void PollCallback(IAsyncResult ar)
        {
            Console.WriteLine("{");

            AnyInfo r = pbx.EndPoll(ar);

            for(int i=0; i<r.user.Length; i++) 
            {
                User existing = null;
                Console.WriteLine("[UserInfo "+r.user[i].cn);
                foreach(User u in listView_users.Items) 
                {
                    if(u.guid==r.user[i].guid)
                    {
                        existing = u;
                        break;
                    }
                }
                if(existing==null) 
                {
                    Console.WriteLine("new="+r.user[i].cn+",active="+r.user[i].active);
                    if(r.user[i].active) 
                    {
                        listView_users.Items.Add(new User(r.user[i]));
                    }
                }
                else
                {
                    if(r.user[i].active) 
                    {
                        existing.Update(r.user[i]);
                    }
                    else
                    {
                        listView_users.Items.Remove(existing);
                    }
                }
                Console.WriteLine("]");
            }
            for(int i=0; i<r.call.Length; i++)
            {
                Console.WriteLine("[CallInfo, user="+r.call[i].user+" call="+r.call[i].call+" "+r.call[i].msg);
                ListView list = null;
                if(r.call[i].user==user_handle) list = listView_calls1;
                foreach(Info info in r.call[i].info)
                {
                    Console.WriteLine("type="+info.type+" vali="+info.vali+" vals="+info.vals);
                }

                if(list!=null) 
                {
                    Call existing = null;
                    foreach(Call c in list.Items) 
                    {
                        if(c.handle==r.call[i].call) 
                        {
                            existing = c;
                            break;
                        }
                    }
                    if(existing==null) 
                    {
                        Console.WriteLine("new="+r.call[i].call+",active="+r.call[i].active);
                        if(r.call[i].active) 
                        {
                            list.Items.Add(new Call(r.call[i]));
                        }
                    }
                    else
                    {
                        if(r.call[i].active) 
                        {
                            existing.Update(r.call[i]);
                        }
                        else
                        {
                            list.Items.Remove(existing);
                        }
                    }
                }
                else
                {
                    foreach(Control c in panel1.Controls)
                    {
                        if(c.GetType()==typeof(MonitorControl))
                        {
                            MonitorControl m = (MonitorControl)c;
                            if(r.call[i].user==m.user)
                            {
                                m.update(r.call[i]);
                            }
                        }
                    }
                }
                Console.WriteLine("]");
            }

            if(session_handle!=0) 
            {
                pbx.BeginPoll(session_handle, asyncPoll, null);
            }
            Console.WriteLine("}");
        }

        internal void MakeCall(string cn, string number, string name)
        {
            int call_handle = pbx.UserCall(user_handle,cn,number,name,0,(Info[])null);
            Console.WriteLine("Makecall "+call_handle);
        }

        private void FileExit_Clicked(object sender, System.EventArgs e)
        {
            Console.WriteLine("Close");
            this.Close();
        }

        private void Form_onExit(object sender, EventArgs evArgs)
        {
            Console.WriteLine("Exit "+session_handle);
            if(session_handle!=0) 
            {
                int save_session_handle = session_handle;
                session_handle = 0;
                pbx.End(save_session_handle);
            }
        }

        private void listView_users_Click(object sender, System.EventArgs e)
        {
            Console.WriteLine("Calls");
            foreach(ListViewItem u in listView_users.SelectedItems)
            {
                CallInfo[] calls = pbx.Calls(session_handle,((User)u).cn);
                foreach(CallInfo c in calls)
                {
                    Console.WriteLine("call.state="+c.state);
                }
            }
        }

        private void listView_users_DoubleClick(object sender, System.EventArgs e)
        {
            Console.WriteLine("DoubleClick " + sender.ToString() + e.ToString());
            foreach(ListViewItem i in listView_users.SelectedItems) 
            {
                if(((User)i).alert!=0)
                {
                    pbx.UserPickup(user_handle,((User)i).cn,0,null,0,(Info[])null);
                }
                else 
                {
                    pbx.UserCall(user_handle,((User)i).cn,null,null,0,(Info[])null);
                }
                Console.WriteLine(i);
            }
        }

        private void contextMenu_calls_Popup(object sender, System.EventArgs e)
        {
            callsClear.Visible = false;
            callsTransfer.Visible = false;
            if(listView_calls1.SelectedItems.Count>0)
            {
                callsClear.Visible = true;
                if(listView_calls1.SelectedItems.Count==2)
                {
                    callsTransfer.Visible = true;
                }
            }
        }

        private void callsClear_event(object sender, System.EventArgs e)
        {
            foreach(Call c in listView_calls1.SelectedItems) 
            {
                pbx.UserClear(c.handle,16,(Info[])null);
            }
        }


        private void callFastClear_event(object sender, System.EventArgs e)
        {
            foreach(Call c in listView_calls1.SelectedItems) 
            {
                pbx.UserClear(c.handle,26,(Info[])null);
            }
        }

        private void callsConnect_event(object sender, System.EventArgs e)
        {
            foreach(Call c in listView_calls1.SelectedItems) 
            {
                pbx.UserConnect(c.handle);
            }
        }

        private void callsTransfer_event(object sender, System.EventArgs e)
        {
            int a=0;
            int b=0;
            foreach(Call c in listView_calls1.SelectedItems)
            {
                if(a==0) a = c.handle;
                else if(b==0) b = c.handle;
            }
            pbx.UserTransfer(a,b);
        }

        private void callsCtComplete_event(object sender, System.EventArgs e)
        {
            foreach(Call c in listView_calls1.SelectedItems)
            {
                pbx.UserCtComplete(c.handle,"999","test");
            }
        }

        private void CallsHold_event(object sender, System.EventArgs e)
        {
            foreach(Call c in listView_calls1.SelectedItems) 
            {
                pbx.UserHold(c.handle);
            }
        }

        private void CallsRetrieve_event(object sender, System.EventArgs e)
        {
            foreach(Call c in listView_calls1.SelectedItems) 
            {
                pbx.UserRetrieve(c.handle);
            }
        }

        private void callsSearch_Click(object sender, System.EventArgs e)
        {
            Search search = new Search(pbx);
            search.ShowDialog();
        }

        private void Config_clicked(object sender, System.EventArgs e)
        {
            RegistryKey regKey = Registry.CurrentUser;
            RegistryKey clientKey = regKey.CreateSubKey("Software\\innovaphone\\client");

            ConfigForm config = new ConfigForm(clientKey);
            config.ShowDialog();
            clientKey.Close();
        }

        private void ViewGroupDetails(object sender, System.EventArgs e)
        {
            if(listView_users.View!=View.Details)
            {
                listView_users.View = System.Windows.Forms.View.Details;
                ColumnHeader c1 = new ColumnHeader();
                c1.Text = "Name";
                c1.Width = 100;
                listView_users.Columns.Add(c1);
                listView_users.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            }
        }

        private void ViewGroupSmallIcons_event(object sender, System.EventArgs e)
        {
            listView_users.View = System.Windows.Forms.View.SmallIcon;
            while(listView_users.Columns.Count!=0)
            {
                listView_users.Columns.Remove(listView_users.Columns[0]);
            }
            
        }

        private void calls1_ItemDrag(object sender, System.Windows.Forms.ItemDragEventArgs e)
        {
            Console.WriteLine("drag");
            this.DoDragDrop(listView_calls1.SelectedItems[0],System.Windows.Forms.DragDropEffects.Copy);
            Console.WriteLine("done");
        }

        private void calls1_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            Console.WriteLine("drag enter");
            e.Effect = System.Windows.Forms.DragDropEffects.Copy;
        }

        private void calls1_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            Console.WriteLine("calls1 drag drop");
            Call call = (Call)e.Data.GetData(typeof(Call));
            System.Drawing.Point p = new System.Drawing.Point(e.X,e.Y);

            if(call!=null)
            {
                foreach(Call c in listView_calls1.Items)
                {
                    if(c.Bounds.Contains(listView_calls1.PointToClient(p)))
                    {
                        if(c!=call)
                        {
                            Console.WriteLine("Transfer");
                            pbx.UserTransfer(call.handle,c.handle);
                        }
                    }
                }
            }
        }

        private void users_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
        {
            Console.WriteLine("users drag enter");
            e.Effect = System.Windows.Forms.DragDropEffects.Copy;
        }

        private void users_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            Console.WriteLine("users drag drop"+e.Data.GetData(typeof(Call)).GetType());
            Call call = (Call)e.Data.GetData(typeof(Call));
            System.Drawing.Point p = new System.Drawing.Point(e.X,e.Y);

            if(call!=null)
            {
                foreach(User u in listView_users.Items)
                {
                    if(u.Bounds.Contains(listView_users.PointToClient(p)))
                    {
                        u.DisplayNormal();
                        pbx.UserRedirect(call.handle,u.cn,"","",(Info[])null);
                        Console.WriteLine("UserRedirect");
                    }
                }
            }
        }

        private void users_DragOver(object sender, System.Windows.Forms.DragEventArgs e)
        {
            System.Drawing.Point p = new System.Drawing.Point(e.X,e.Y);
            foreach(User u in listView_users.Items)
            {
                if(u.Bounds.Contains(listView_users.PointToClient(p)))
                {
                    u.DisplaySelect();
                }
                else 
                {
                    u.DisplayNormal();
                }
            }
        }

        private void button_call_Click(object sender, System.EventArgs e)
        {
            MakeCall(null,dial_name? null:calls1_comboBox.Text,dial_name? calls1_comboBox.Text:null);
            calls1_comboBox.Items.Add(new dialed(dial_name,calls1_comboBox.Text));
        }

        private void Name_Number_Click(object sender, System.EventArgs e)
        {
            if(dial_name)
            {
                dial_name = false;
                button_Name_Number.Text = "Number";
            }
            else
            {
                dial_name = true;
                button_Name_Number.Text = "Name";
            }
        }

        private void dialed_selected(object sender, System.EventArgs e)
        {
            Console.WriteLine("dialed_seleceted");
            if(calls1_comboBox.SelectedItem!=null)
            {
                if(((dialed)calls1_comboBox.SelectedItem).name)
                {
                    button_Name_Number.Text = "Name";
                    dial_name = true;
                }
                else
                {
                    button_Name_Number.Text = "Number";
                    dial_name = false;
                }
            }
        }

        private void listView_users_SelectedIndexChanged(object sender, System.EventArgs e)
        {
        
        }
    }

    struct dialed
    {
        public dialed(bool name, string addr)
        {
            this.name = name;
            this.addr = addr;
        }

        public override string ToString()
        {
            return addr;
        }

        public bool name;
        string addr;
    }
}
