using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.Win32;

namespace innovaphone
{
	/// <summary>
	/// Summary description for config.
	/// </summary>
	public class ConfigForm : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Label account_label;
        private System.Windows.Forms.Label password_label;
        private System.Windows.Forms.Label user_label;
        private System.Windows.Forms.Label pbx_url_label;
        private System.Windows.Forms.TextBox account_textBox;
        private System.Windows.Forms.TextBox password_textBox;
        private System.Windows.Forms.TextBox user_textBox;
        private System.Windows.Forms.TextBox pbx_url_textBox;
        private System.Windows.Forms.Button ok_button;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox monitor_textBox;

        private RegistryKey configKey;

		public ConfigForm(RegistryKey configKey)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

            this.configKey = configKey;

            object o = configKey.GetValue("account");
            if(o!=null) account_textBox.Text = o.ToString();
            o = configKey.GetValue("password");
            if(o!=null) password_textBox.Text = o.ToString();
            o = configKey.GetValue("user");
            if(o!=null) user_textBox.Text = o.ToString();
            o = configKey.GetValue("url");
            if(o!=null) pbx_url_textBox.Text = o.ToString();

            o = configKey.GetValue("monitor");
            if(o!=null) this.monitor_textBox.Lines = (string[])o;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.password_textBox = new System.Windows.Forms.TextBox();
            this.account_label = new System.Windows.Forms.Label();
            this.ok_button = new System.Windows.Forms.Button();
            this.account_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.password_label = new System.Windows.Forms.Label();
            this.monitor_textBox = new System.Windows.Forms.TextBox();
            this.pbx_url_label = new System.Windows.Forms.Label();
            this.pbx_url_textBox = new System.Windows.Forms.TextBox();
            this.user_label = new System.Windows.Forms.Label();
            this.user_textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // password_textBox
            // 
            this.password_textBox.Location = new System.Drawing.Point(88, 36);
            this.password_textBox.Name = "password_textBox";
            this.password_textBox.Size = new System.Drawing.Size(160, 20);
            this.password_textBox.TabIndex = 5;
            this.password_textBox.Text = "";
            // 
            // account_label
            // 
            this.account_label.Location = new System.Drawing.Point(24, 16);
            this.account_label.Name = "account_label";
            this.account_label.Size = new System.Drawing.Size(56, 16);
            this.account_label.TabIndex = 0;
            this.account_label.Text = "Account";
            // 
            // ok_button
            // 
            this.ok_button.Location = new System.Drawing.Point(292, 12);
            this.ok_button.Name = "ok_button";
            this.ok_button.Size = new System.Drawing.Size(75, 20);
            this.ok_button.TabIndex = 9;
            this.ok_button.Text = "OK";
            this.ok_button.Click += new System.EventHandler(this.config_ok);
            // 
            // account_textBox
            // 
            this.account_textBox.Location = new System.Drawing.Point(88, 12);
            this.account_textBox.Name = "account_textBox";
            this.account_textBox.Size = new System.Drawing.Size(160, 20);
            this.account_textBox.TabIndex = 4;
            this.account_textBox.Text = "";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(24, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "Monitor";
            // 
            // password_label
            // 
            this.password_label.Location = new System.Drawing.Point(24, 40);
            this.password_label.Name = "password_label";
            this.password_label.Size = new System.Drawing.Size(56, 16);
            this.password_label.TabIndex = 1;
            this.password_label.Text = "Password";
            // 
            // monitor_textBox
            // 
            this.monitor_textBox.Location = new System.Drawing.Point(88, 108);
            this.monitor_textBox.Multiline = true;
            this.monitor_textBox.Name = "monitor_textBox";
            this.monitor_textBox.Size = new System.Drawing.Size(160, 40);
            this.monitor_textBox.TabIndex = 8;
            this.monitor_textBox.Text = "";
            // 
            // pbx_url_label
            // 
            this.pbx_url_label.Location = new System.Drawing.Point(24, 88);
            this.pbx_url_label.Name = "pbx_url_label";
            this.pbx_url_label.Size = new System.Drawing.Size(56, 16);
            this.pbx_url_label.TabIndex = 3;
            this.pbx_url_label.Text = "PBX Url";
            // 
            // pbx_url_textBox
            // 
            this.pbx_url_textBox.Location = new System.Drawing.Point(88, 84);
            this.pbx_url_textBox.Name = "pbx_url_textBox";
            this.pbx_url_textBox.Size = new System.Drawing.Size(240, 20);
            this.pbx_url_textBox.TabIndex = 7;
            this.pbx_url_textBox.Text = "";
            // 
            // user_label
            // 
            this.user_label.Location = new System.Drawing.Point(24, 64);
            this.user_label.Name = "user_label";
            this.user_label.Size = new System.Drawing.Size(56, 16);
            this.user_label.TabIndex = 2;
            this.user_label.Text = "User";
            // 
            // user_textBox
            // 
            this.user_textBox.Location = new System.Drawing.Point(88, 60);
            this.user_textBox.Name = "user_textBox";
            this.user_textBox.Size = new System.Drawing.Size(160, 20);
            this.user_textBox.TabIndex = 6;
            this.user_textBox.Text = "";
            // 
            // ConfigForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(376, 166);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.label1,
                                                                          this.monitor_textBox,
                                                                          this.ok_button,
                                                                          this.pbx_url_textBox,
                                                                          this.user_textBox,
                                                                          this.password_textBox,
                                                                          this.account_textBox,
                                                                          this.pbx_url_label,
                                                                          this.user_label,
                                                                          this.password_label,
                                                                          this.account_label});
            this.Name = "ConfigForm";
            this.Text = "Config";
            this.ResumeLayout(false);

        }
		#endregion

        private void config_ok(object sender, System.EventArgs e)
        {
            string[] test = {"Group1","Group2"};

            configKey.SetValue("account",account_textBox.Text);
            configKey.SetValue("password",password_textBox.Text);
            configKey.SetValue("user",user_textBox.Text);
            configKey.SetValue("url",pbx_url_textBox.Text);
            configKey.SetValue("monitor",monitor_textBox.Lines);
            this.Close();
        }
	}
}
