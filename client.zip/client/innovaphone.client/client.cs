using System;
using System.Windows.Forms;
using System.Net;
using Microsoft.Win32;
using innovaphone.com.innovaphone.www;

namespace innovaphone
{
    /// <summary>
    /// Summary description for Class1.
    /// </summary>
    class client
    {
        [STAThread]
        static void Main(string[] args)
        {
            RegistryKey regKey = Registry.CurrentUser;
            bool config_ok = false;
            string user=null;
            string[] monitor=null;
            pbx pbx=null;
            do 
            {
                try
                {
                    string pbx_url;
                    string account;
                    string password;

                    RegistryKey clientKey = regKey.OpenSubKey("Software\\innovaphone\\client");
                    account = (string)clientKey.GetValue("account");
                    password = (string)clientKey.GetValue("password");
                    user = (string)clientKey.GetValue("user");
                    pbx_url = (string)clientKey.GetValue("url");
                    monitor = (string[])clientKey.GetValue("monitor");
                    clientKey.Close();

                    // Obtain a Proxy to the SOAP URL
                    pbx = new pbx();
                    pbx.Url = pbx_url;
                    pbx.Credentials = new NetworkCredential(account,password,"");

                    config_ok = true;
                }
                catch 
                {
                    RegistryKey clientKey = regKey.CreateSubKey("Software\\innovaphone\\client");
                    ConfigForm config = new ConfigForm(clientKey);
                    config.ShowDialog();
                }
            } while(!config_ok);

            Application.Run(new MainForm(pbx,user,monitor));
        }
    }
}
