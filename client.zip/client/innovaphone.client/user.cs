using System;
using System.Windows.Forms;
using innovaphone.com.innovaphone.www;

namespace innovaphone
{

    /// <summary>
    /// Summary description for user.
    /// </summary>
    public class User : ListViewItem
    {
        public User(UserInfo userInfo)
        {
            normal = true;
            cn = userInfo.cn;
            guid = userInfo.guid;
            lv_cn = new ListViewSubItem();
            lv_h323 = new ListViewSubItem();
            lv_loc = new ListViewSubItem();
            this.SubItems.Add(lv_h323);
            this.SubItems.Add(lv_cn);
            this.SubItems.Add(lv_loc);
            Update(userInfo);
        }

        public void Update(UserInfo userInfo)
        {
            Text = userInfo.e164;
            state = userInfo.state;
            channel = userInfo.channel;
            alert = userInfo.alert;

            lv_cn.Text = cn;
            lv_h323.Text = userInfo.h323;

            foreach(Info i in userInfo.info)
            {
                Console.WriteLine("Info="+i.type+" "+i.vali+" "+i.vals);
                if(i.type=="loc") lv_loc.Text = i.vals;
            }

            if(normal)
            {
                normal = false;
                DisplayNormal();
            }
            else
            {
                normal = true;
                DisplaySelect();
            }
            foreach(Group g in userInfo.groups) 
            {
                Console.WriteLine("Group="+g.group+" Active="+g.active);
            }
        }

        public void DisplayNormal()
        {
            if(!normal)
            {
                normal = true;

                this.ForeColor = System.Drawing.Color.LightGray;

                if(state!=0)
                {
                    this.ForeColor = System.Drawing.Color.Green;
                }
                if(channel!=0) 
                {
                    this.ForeColor = System.Drawing.Color.Brown;
                }
                if(alert!=0)
                {
                    this.ForeColor = System.Drawing.Color.Red;
                }
            }
        }

        public void DisplaySelect()
        {
            if(normal)
            {
                normal = false;
                this.ForeColor = System.Drawing.Color.DarkRed;
            }
        }

        bool normal;
        internal string guid;
        internal string cn;
        internal int state;
        internal int channel;
        internal int alert;

        ListViewSubItem lv_cn;
        ListViewSubItem lv_h323;
        ListViewSubItem lv_loc;
    }
}
