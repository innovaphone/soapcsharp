using System;
using System.Windows.Forms;
using innovaphone.com.innovaphone.www;

namespace innovaphone
{
	/// <summary>
	/// Summary description for call.
	/// </summary>
	public class Call : ListViewItem
	{
        static string[] state_text = {"Idle","Setup","SetupAck","CallProc","Alert","Connect","Disc-In","Disc-Out"};
		public Call(CallInfo callInfo)
        {
            user = callInfo.user;
            handle = callInfo.call;
            state = callInfo.state;
            peer = new ListViewSubItem();
            add_no = new ListViewSubItem();

            if((callInfo.state &0x80)==0) this.Text = ">";
            else this.Text = "<";

            for(int i=0; i<callInfo.No.Length; i++) 
            {
                Console.WriteLine("No "+callInfo.No[i].type+"("+callInfo.No[i].h323+"/"+callInfo.No[i].e164+")");
                if(callInfo.No[i].type=="peer") 
                {
                    peer.Text = callInfo.No[i].e164+":"+callInfo.No[i].h323;
                }
                else
                {
                    add_no.Text = add_no.Text+callInfo.No[i].type+"("+callInfo.No[i].e164+":"+callInfo.No[i].h323+")";
                }
            }
            SubItems.Add(peer);
            state_item = this.SubItems.Add(state_text[callInfo.state &0x7f]);
            SubItems.Add(add_no);
        }

        public void Update(CallInfo callInfo)
        {
            state = callInfo.state;

            if((callInfo.state &0x80)==0) this.Text = ">";
            else this.Text = "<";

            for(int i=0; i<callInfo.No.Length; i++) 
            {
                Console.WriteLine("No "+callInfo.No[i].type+"("+callInfo.No[i].h323+"/"+callInfo.No[i].e164+")");
                if(callInfo.No[i].type=="peer") 
                {
                    peer.Text = callInfo.No[i].e164+":"+callInfo.No[i].h323;
                }
            }

            state_item.Text = state_text[callInfo.state &0x7f];
            if((callInfo.state &0x100)!=0)
            {
                state_item.Text = "Hold("+state_item.Text+")";
            }
        }

        internal int user;
        internal int handle;
        internal int state;
        ListViewSubItem peer;
        ListViewSubItem add_no;
        ListViewSubItem state_item;
	}
}
