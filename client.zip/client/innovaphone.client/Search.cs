using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using innovaphone.com.innovaphone.www;

namespace innovaphone
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Search : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Panel search_filter_panel;
        private System.Windows.Forms.TextBox search_textBox;
        private System.Windows.Forms.ListView search_listView;

        private pbx pbx;
        private System.Windows.Forms.ColumnHeader header_no;
        private System.Windows.Forms.ColumnHeader header_h323;
        private System.Windows.Forms.ColumnHeader header_cn;
        private System.Windows.Forms.ColumnHeader header_loc;
        private System.Windows.Forms.Button search_name_number_button;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Search(pbx pbx)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

            this.pbx = pbx;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

        private void Name_TextChanged(object sender, System.EventArgs e)
        {
            pbx search;
            search = new pbx();
            search.Url = pbx.Url;
            search.Credentials = pbx.Credentials;
            UserInfo[] users;
            string cn = null;
            string h323 = null;
            string e164 = null;
            
            if(search_name_number_button.Text=="cn") cn = search_textBox.Text;
            else if(search_name_number_button.Text=="h323") h323 = search_textBox.Text;
            else if(search_name_number_button.Text=="no") e164 = search_textBox.Text;
            users = search.FindUser("x",cn,h323,e164,8,0);
            Console.WriteLine("users="+users.Length);
            search_listView.Items.Clear();
            for(int i=0; i<users.Length; i++) 
            {
                foreach(Info info in users[i].info)
                {
                    if(info.type=="loc")
                    {
                        string url = pbx.LocationUrl("x",info.vals);
                        Console.WriteLine("URL="+url);
                    }
                }
                search_listView.Items.Add(new User(users[i]));
            }
        }

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.search_filter_panel = new System.Windows.Forms.Panel();
            this.search_textBox = new System.Windows.Forms.TextBox();
            this.search_name_number_button = new System.Windows.Forms.Button();
            this.search_listView = new System.Windows.Forms.ListView();
            this.header_no = new System.Windows.Forms.ColumnHeader();
            this.header_h323 = new System.Windows.Forms.ColumnHeader();
            this.header_cn = new System.Windows.Forms.ColumnHeader();
            this.header_loc = new System.Windows.Forms.ColumnHeader();
            this.search_filter_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // search_filter_panel
            // 
            this.search_filter_panel.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                              this.search_name_number_button,
                                                                                              this.search_textBox});
            this.search_filter_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.search_filter_panel.Name = "search_filter_panel";
            this.search_filter_panel.Size = new System.Drawing.Size(408, 40);
            this.search_filter_panel.TabIndex = 0;
            // 
            // search_textBox
            // 
            this.search_textBox.Location = new System.Drawing.Point(88, 8);
            this.search_textBox.Name = "search_textBox";
            this.search_textBox.Size = new System.Drawing.Size(176, 20);
            this.search_textBox.TabIndex = 1;
            this.search_textBox.Text = "";
            this.search_textBox.TextChanged += new System.EventHandler(this.Name_TextChanged);
            // 
            // search_name_number_button
            // 
            this.search_name_number_button.Location = new System.Drawing.Point(8, 8);
            this.search_name_number_button.Name = "search_name_number_button";
            this.search_name_number_button.Size = new System.Drawing.Size(64, 23);
            this.search_name_number_button.TabIndex = 2;
            this.search_name_number_button.Text = "cn";
            this.search_name_number_button.Click += new System.EventHandler(this.name_number_toggle);
            // 
            // search_listView
            // 
            this.search_listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                              this.header_no,
                                                                                              this.header_h323,
                                                                                              this.header_cn,
                                                                                              this.header_loc});
            this.search_listView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.search_listView.Location = new System.Drawing.Point(0, 40);
            this.search_listView.Name = "search_listView";
            this.search_listView.Size = new System.Drawing.Size(408, 226);
            this.search_listView.TabIndex = 1;
            this.search_listView.View = System.Windows.Forms.View.Details;
            // 
            // header_no
            // 
            this.header_no.Text = "no";
            this.header_no.Width = 40;
            // 
            // header_h323
            // 
            this.header_h323.Text = "h323";
            this.header_h323.Width = 40;
            // 
            // header_cn
            // 
            this.header_cn.Text = "cn";
            this.header_cn.Width = 120;
            // 
            // header_loc
            // 
            this.header_loc.Text = "loc";
            // 
            // Search
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(408, 266);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.search_listView,
                                                                          this.search_filter_panel});
            this.Name = "Search";
            this.Text = "Search";
            this.search_filter_panel.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

        private void name_number_toggle(object sender, System.EventArgs e)
        {
            if(search_name_number_button.Text=="cn") search_name_number_button.Text="h323";
            else if(search_name_number_button.Text=="h323") search_name_number_button.Text="no";
            else search_name_number_button.Text="cn";

            Name_TextChanged(sender,e);
        }
	}
}
